///////////////////////////////////////////////////////////////////////////
// Copyright © Esri. All Rights Reserved.
//
// Licensed under the Apache License Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//    http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
///////////////////////////////////////////////////////////////////////////

define([
  'dojo/_base/declare',
  './LayerInfoForDefaultService'
], function(declare, LayerInfoForDefaultService) {
  var clazz = declare(LayerInfoForDefaultService, {

    // operLayer = {
    //    layerObject: layer,
    //    title: layer.label || layer.title || layer.name || layer.id || " ",
    //    id: layerId || " ",
    //    subLayers: [operLayer, ... ],
    //    mapService: {layerInfo: , subId: },
    //    collection: {layerInfo: }
    // };
    constructor: function( operLayer, map ) {
      this.isTiled = true;
      /*jshint unused: false*/
    },

    _initVisible: function() {
    },

    _setTopLayerVisible: function(visible) {
      /*jshint unused: false*/
    },

    setLayerVisiblefromTopLayer: function() {
    },

    getOpacity: function() {
    },

    setOpacity: function(opacity) {
      /*jshint unused: false*/
    },

    isShowInMap: function() {
      return this.originOperLayer.mapService.layerInfo.layerObject.visible;
    }
  });
  return clazz;
});
